# Surgical Tools Dataset > Labelled Set
https://universe.roboflow.com/surgical-tools/surgical-tools-dataset

Provided by a Roboflow user
License: CC BY 4.0

