# Surgical-Tool-Detection > 2024-09-14 6:12am
https://universe.roboflow.com/hophacks/surgical-tool-detection-cx3g7

Provided by a Roboflow user
License: CC BY 4.0

