# Surgical Tool Detection > 2024-09-14 3:36pm
https://universe.roboflow.com/homesecurity-upzel/surgical-tool-detection-qied2-l3o6w

Provided by a Roboflow user
License: MIT

